# Toko_Buku
 Website toko buku sederhana dengan bootstrap dan php

[![Coverage Status](http://img.shields.io/coveralls/badges/badgerbadgerbadger.svg?style=flat-square)](https://coveralls.io/r/badges/badgerbadgerbadger) [![License](http://img.shields.io/:license-mit-blue.svg?style=flat-square)](http://badges.mit-license.org)

## How To Install

1. Upload Database [toko_buku](https://github.com/gagassurya19/Toko_Buku/blob/master/SQL/toko_buku.sql) on your database
2. pull this repository to your file server
3. Done.

> Thank you

![tokobuku](https://github.com/gagassurya19/Toko_Buku/blob/master/SQL/1.png)
![tokobuku](https://github.com/gagassurya19/Toko_Buku/blob/master/SQL/2.png)
![tokobuku](https://github.com/gagassurya19/Toko_Buku/blob/master/SQL/3.png)
![tokobuku](https://github.com/gagassurya19/Toko_Buku/blob/master/SQL/4.png)
---
